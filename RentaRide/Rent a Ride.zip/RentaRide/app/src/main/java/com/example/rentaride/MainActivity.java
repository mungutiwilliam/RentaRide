package com.example.rentaride;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btn_signup, btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btn_signup=(Button) findViewById(R.id.btn_next);
        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opensignup();
            }
        });


        btnLogin=(Button) findViewById(R.id.btn_next);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openlogin();
            }
        });
    }

    public void opensignup(){
        Intent intent= new Intent(this,signup.class );
        startActivity(intent);

    }

    public void openlogin(){
        Intent intent= new Intent(this,login.class );
        startActivity(intent);

    }
}